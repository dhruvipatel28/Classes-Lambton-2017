//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var x : String = "Dhruvi"    // Give the Datatype by : after a variable name
print ("------------------------ Double For Loop ---------------------")

var blue, red, green : Double // Multiplr double variable in one line


for i in 1...10
{
    var s = 0
    for _ in 1...i
    {
        s = s + 5
    }
    print("5 x \(i) = \(s)")
}


print ("------------------------ Single For Loop ---------------------")
for i in 1...10
{
    print("5 x \(i) = " , (5*i))
}



// Definr Range
print ("------------------------ Range ---------------------")

let Range1 = -1...5

/*
 
 There is no limit define for value less then the 5
 So any value will true like -9999 or 0 or -1 or any >5
 */
Range1.contains(7) // false
Range1.contains(4) // true
Range1.contains(-1) // False

for k in Range1
{
    print("value", k )
}



Range1.lowerBound
print("Lower bound  : " , Range1.lowerBound)



print("Upper bound  : " , Range1.upperBound)

// Display 10 to 1 using While


print ("------------------------ While ---------------------")

var n = 10

while n != 0
{
    print ("N is : \(n)")
    n = n - 1;
}

print ("------------------------ Repeat ---------------------")

/*
var m = 10
Repeated
{
    print("M : is \(m)");
    m = m - 1;
}
while m > 0
*/

print (" -------------------  Switch  ----------- ")

var char1 = "s"
switch char1
{
case  "a" , "s" , "A" , "S" :
    print("Char is a or s")
case  "t" :
    print("Char is t")
case "y" :
    print("Char id y")
default:
    print("Char doesn't match")
}


print (" -------------------  Switch for range match  ----------- ")


var count = 50
var status: String

switch count
{
     case 1..<5:
         status = "Child"
     case 5..<10:
         status = "Big Child"
     case 10..<19:
         status = "Teenager"
     case 20..<30:
         status = "Adult"
     case 31..<45:
         status = "Above 30"
     case 45...50:
         status = "Near to his/her 50s"
    default:
        status = "Entering invalid age"
}
 print(" You are " , status)



print (" -------------------  Multi line declaration  ----------- ")

let quotation = """
The White Rabbit put on his spectacles.  "Where shall I begin,
please your Majesty?" he asked.

"Begin at the beginning," the King said gravely, "and go on
till you come to the end; then stop."
"""

print("Multi Line String Declaration with 3x(\") " , quotation)


print("------------------- string functions ---------------")

var mystring = "I have a string"

print("############  appended \n")
print(mystring.append("I appended the string") , mystring)


print("\n\n\n############  appended")
if mystring.isEmpty
{
    print("Mystring Is empty ")
}
else
{
    print("Mystring Is Not empty ")
}


print("\n\n\n############  lowercase()")

print("Lowercase" , mystring.lowercased())

print("\n\n\n\n###################  Count ")

print("Count of String ", mystring.count)

print("\n\n\n###################  split ")

print( "split" , mystring.split(separator: "v"))


print("\n\n\n\n###########    characters view" )


print( " charactersview \n " , mystring.characters)


print("\n\n\n\n###########    characters view" )

print( " " , mystring.contains("have"))


print("\n\n\n   #########    ")

















