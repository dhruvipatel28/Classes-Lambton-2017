//
//  StudentEntryViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : CO719320
//  Student Name : Dhruvi

import UIKit

class StudentEntryViewController: UIViewController
{

    var isEmpty = false
    var errorMessage : String!
    var email_address :String!
    
    @IBOutlet weak var txt_studentID: UITextField!
    @IBOutlet weak var txt_studentName: UITextField!
    @IBOutlet weak var txt_email_address: UITextField!
    @IBOutlet weak var txt_birthDate: UITextField!
    @IBOutlet weak var txt_sub_math: UITextField!
    @IBOutlet weak var txt_sub_sci: UITextField!
    @IBOutlet weak var txt_sub_com: UITextField!
    @IBOutlet weak var txt_sub_gk: UITextField!
    @IBOutlet weak var txt_sub_lang: UITextField!
    
    
    @IBAction func btn_show_result(_ sender: UIButton)
    {
       // checkIsEmpty()
       //print(validateDate()  , "----         validate Data ----")
       
    } // btn_click
    
    
    func validateDate() -> Bool
    {
        // ------ Student ID
        if(txt_studentID.text?.characters.first != "C"  && txt_studentID.text?.characters.first != "c")
        {
            print("Student ID invelid ---------- " , txt_studentID.text?.characters.first! )
        }
        
                // -------- Student Name
        let nameRegEx = "[A-Z a-z]{5,}"
        let nameMatch = NSPredicate(format:"SELF MATCHES %@", nameRegEx)
        if( !(nameMatch.evaluate(with: txt_studentName.text!))  )
        {
            print("Student Name invelid")
        }
                // -------- Student Email-address
        if(!(isValidEmail(user_name: txt_email_address.text!)) )
        {
            print("Student Email invelid")
        }
                // -------- Student birth date
        if( Date() < validDate())
        {
            print("Student Birth Date invelid")
        }
        return true
    } // validate
    
    func validateMarks() -> Bool
    {
       
        
        return true
    }
    
    
    
    func checkIsEmpty()
    {
        isEmpty = false
        if (!(txt_studentID.hasText))
        {
            isEmpty = true
            txt_studentID.attributedPlaceholder = NSAttributedString(string:"Please enter Student Id",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        }
        if (!(txt_studentName.hasText))
        {
            isEmpty = true
            txt_studentName.attributedPlaceholder = NSAttributedString(string:"Please enter Student Name",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        }
        if (!(txt_email_address.hasText))
        {
            isEmpty = true
            txt_email_address.attributedPlaceholder = NSAttributedString(string:"Please enter Student Email-Id",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        }
        if (!(txt_birthDate.hasText))
        {
            isEmpty = true
            txt_birthDate.attributedPlaceholder = NSAttributedString(string:"Please enter BirthDate",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        }
        if (!(txt_sub_math.hasText))
        {
            isEmpty = true
            txt_sub_math.attributedPlaceholder = NSAttributedString(string:"! Marks",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        }
        if (!(txt_sub_com.hasText))
        {
            isEmpty = true
            txt_sub_com.attributedPlaceholder = NSAttributedString(string:"! Marks ",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        }
        if (!(txt_sub_sci.hasText))
        {
            isEmpty = true
            txt_sub_sci.attributedPlaceholder = NSAttributedString(string:"! Marks ",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        }
        if (!(txt_sub_gk.hasText))
        {
            isEmpty = true
            txt_sub_gk.attributedPlaceholder = NSAttributedString(string:"! Marks ",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        }
        if (!(txt_sub_lang.hasText))
        {
            isEmpty = true
            txt_sub_lang.attributedPlaceholder = NSAttributedString(string:"! Marks ",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        }
        
        if(!isEmpty)
        {
            print(" --------- call validateDate() ------ here " )
        }
    }
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        txt_email_address.text = self.email_address!
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btn_logout(_ sender: UIBarButtonItem)
    {
        self.dismiss(animated: true, completion: nil)
    }
   
    func isValidEmail(user_name:String) -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailMatch = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailMatch.evaluate(with: user_name)
    }
    
    func validDate() -> Date
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-mm-yyyy"
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
        var birthDate = dateFormatter.date(from: txt_birthDate.text!)
        return birthDate!
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
     
     if date1 < date2  {
     print("date1 is earlier than date2")
     }
     
     
     let dateFormatter = DateFormatter()
     dateFormatter.dateFormat = "dd-mm-yyyy"
     dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
     emp.birthDate = dateFormatter.date(from: txtEmpBirthdate.text!)

    */

}
