//
//  Student.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0719320
//  Student Name : Dhruvi

import Foundation


class Student
{
    var studentID : String!
    var studentName : String!
    var studentEmail : String!
    var studentBirtDate : String!
    var math: Int!
    var sci : Int!
    var lang: Int!
    var com: Int!
    var gk : Int!
    
    init()
    {
        studentID = ""
        studentName = " "
        studentEmail = " "
        studentBirtDate = " "
        math = 0
        sci = 0
        lang = 0
        com = 0
        gk = 0
    }
    
    init(_ id: String, _ name: String , _ email:String , _ birth:String , _ math : Int )
    {
        self.studentID = id
        self.studentName = name
        self.studentEmail = email
        self.math = math
    }
    
}
