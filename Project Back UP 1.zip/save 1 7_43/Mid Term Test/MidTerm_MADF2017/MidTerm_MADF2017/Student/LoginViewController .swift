//
//  ViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : CO719320
//  Student Name : Dhruvi

import UIKit

class LoginViewController : UIViewController
{

    @IBOutlet weak var txt_userName: UITextField!
    @IBOutlet weak var txt_password: UITextField!
    var isEmpty = false
    
    
    @IBAction func btn_login(_ sender: UIButton)
    {
        isEmpty = false
        if (!(txt_userName.hasText))
        {
            isEmpty = true
            txt_userName.attributedPlaceholder = NSAttributedString(string:"Please enter User Name",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        }
        if (!(txt_password.hasText))
        {
            isEmpty = true
            txt_password.attributedPlaceholder = NSAttributedString(string:"Please enter Password",attributes: [NSAttributedStringKey.foregroundColor: UIColor.red])
        }
        
        if(!isEmpty)
        {
            if(!(isValidEmail(user_name: txt_userName.text!)) )
            {
                showAlert()
            }
            else
            {
                goNext()
            }
        }
        //print(isValidEmail(user_name: txt_userName.text!))
       
     } // bnt_click
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func goNext()
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let studentEntryVC = storyBoard.instantiateViewController(withIdentifier: "studentEntryViewController") as! StudentEntryViewController
        self.present(studentEntryVC, animated: true, completion: nil)
    }
    
    func showAlert()
    {
        let alert  = UIAlertController(title: "Login Failed", message: "Invalid user id or password", preferredStyle: UIAlertControllerStyle.alert)
        
        let actionTryAgain = UIAlertAction(title: "Try Again", style: UIAlertActionStyle.destructive, handler: nil)
        let actiionOk = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
        
        alert.addAction(actionTryAgain)
        alert.addAction(actiionOk)
        
        self.present(alert, animated: true, completion: nil)

    }
    
    func isValidEmail(user_name:String) -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailMatch = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailMatch.evaluate(with: user_name)
    }
    
    
    //-------- Student Id Velidation
    func isVelidId(user_name:String) -> Bool
    {
        var char = user_name
        print( char.characters.popFirst()! , " ")
        return true
    }
    
    

}

