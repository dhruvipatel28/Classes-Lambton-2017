//
//  StudentEntryViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : CO719320
//  Student Name : Dhruvi

import UIKit

class StudentEntryViewController: UIViewController
{

    @IBOutlet weak var txt_studentID: UITextField!
    @IBOutlet weak var txt_studentName: UITextField!
    @IBOutlet weak var txt_email_address: UITextField!
    @IBOutlet weak var txt_birthDate: UITextField!
    @IBOutlet weak var txt_sub_math: UITextField!
    @IBOutlet weak var txt_sub_sci: UITextField!
    @IBOutlet weak var txt_sub_com: UITextField!
    @IBOutlet weak var txt_sub_gk: UITextField!
    @IBOutlet weak var txt_sub_lang: UITextField!
    
    
    @IBAction func btn_show_result(_ sender: UIButton)
    {
        print(txt_studentID.hasText)
    }
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btn_logout(_ sender: UIBarButtonItem)
    {
        self.dismiss(animated: true, completion: nil)
    }
   
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
